package com.example.hells.androidtic_tac_toe;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
import java.util.List;

public class TicTacToeActivity extends AppCompatActivity {

    // static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    static final int DIALOG_NEW_GAME_ID = 0;

    private char player;
    private String gameName;
    private DatabaseReference mDatabase;

    private TicTacToeGame mGame;
    // Buttons making up the board
    private Button mBoardButtons[];

    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;
    private boolean multiplayer = false;
    private char mTurn;

    // Various text displayed
    private TextView mInfoTextView, thw, taw, tt;
    private TextView mResultsTextView;

    boolean mGameOver = false;
    boolean mSoundOn = true;

    private BoardView mBoardView;
    private SharedPreferences mPrefs;

    int humanWins, androidWins , ties;
    int turn;
    int selected;

    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;
            //Check if position is enabled

            if (!mGameOver && mTurn == player && posEnabled(pos)) {
                setMove(pos);
                checkWinner();
            }
            return false;
        }
    };

    void checkWinner(){
        int winner = mGame.checkForWinner();
        Log.d("winner: ", Integer.toString(winner));
        mDatabase = FirebaseDatabase.getInstance().getReference();

        if (winner == 0)
            if(mTurn == 'N'){
                mInfoTextView.setText("Esperando a otro Jugador");
            }else{
                mInfoTextView.setText("Turno de " + Character.toString(mTurn));
            }
        else if (winner == 1) {
            mInfoTextView.setText(R.string.result_tie);
            if(!mGameOver){
                ties++;
                mDatabase.child("games").child(gameName).child("scores").child("ties").setValue(ties);
            }
            thw.setText("" + humanWins);
            taw.setText("" + androidWins);
            tt.setText("" + ties);
            mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
            mResultsTextView.setText("");

            mGameOver = true;
            mDatabase.child("games").child(gameName).child("game_over").setValue(true);

        }
        else if (winner == 2) {
            //Log.d("ganooo  : ", "asdfdsf");
            String defaultMessage = getResources().getString(R.string.result_human_wins);
            String msg = mPrefs.getString("victory_message", defaultMessage);
            //Log.d("win msg : ", msg);
            mInfoTextView.setText(Character.toString(TicTacToeGame.HUMAN_PLAYER) + " ganador!");
            if(!mGameOver){
                humanWins++;
                mDatabase.child("games").child(gameName).child("scores").child("x_wins").setValue(humanWins);
            }
            thw.setText("" + humanWins);
            taw.setText("" + androidWins);
            tt.setText("" + ties);
            mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
            mResultsTextView.setText("");
            mGameOver = true;
            mDatabase.child("games").child(gameName).child("game_over").setValue(true);

        }
        else{
            mInfoTextView.setText(Character.toString(TicTacToeGame.COMPUTER_PLAYER) + " ganador!");
            if(!mGameOver){
                androidWins++;
                mDatabase.child("games").child(gameName).child("scores").child("o_wins").setValue(humanWins);
            }
            thw.setText("" + humanWins);
            taw.setText("" + androidWins);
            tt.setText("" + ties);
            mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
            mResultsTextView.setText("");
            mGameOver = true;
            mDatabase.child("games").child(gameName).child("game_over").setValue(true);
        }
    }

    private void setMove(int location) {
        //mGame.setMove(player, location);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.child("games").child(gameName).child("board").child(Integer.toString(location)).setValue(Character.toString(player));

        if (TicTacToeGame.HUMAN_PLAYER == player) {
            mDatabase.child("games").child(gameName).child("player_turn").setValue(Character.toString(TicTacToeGame.COMPUTER_PLAYER));
            if(mSoundOn)
                mHumanMediaPlayer.start(); // Play the sound effect
        } else {
            mDatabase.child("games").child(gameName).child("player_turn").setValue(Character.toString(TicTacToeGame.HUMAN_PLAYER));
            if(mSoundOn)
                mComputerMediaPlayer.start(); // Play the sound effect
        }
        mBoardView.invalidate();
    }

    private boolean validateStartNewGame(){
        if (!mGameOver && turn != -1){
            Toast.makeText(this, "Primero debe terminar el juego", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void startNewGame(){
        if (!validateStartNewGame()){
            return;
        }

        List<String> board = Arrays.asList(new String[]{" "," "," "," "," "," "," "," "," "});
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.child("games").child(gameName).child("board").setValue(board);
        turn++;
        mDatabase.child("games").child(gameName).child("init_turn").setValue(turn);
        if(turn == 0){

        }else{
            if(turn % 2 == 0){
                    mDatabase.child("games").child(gameName).child("player_turn").setValue("X");
                }else{
                    mDatabase.child("games").child(gameName).child("player_turn").setValue("O");
                }
        }

        //mGame.clearBoard();
        mBoardView.invalidate();

        thw.setText("" + humanWins);
        taw.setText("" + androidWins);
        tt.setText("" + ties);
        mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
        mResultsTextView.setText("");
        mGameOver = false;
        mDatabase.child("games").child(gameName).child("game_over").setValue(false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSoundOn = mPrefs.getBoolean("sound", true);
        Bundle b = getIntent().getExtras();
        player = b.getChar("player");
        gameName = b.getString("gameName");
        mDatabase = FirebaseDatabase.getInstance().getReference();
        //mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);

        mInfoTextView = (TextView) findViewById(R.id.information);
        thw = (TextView) findViewById(R.id.humanWins);
        taw = (TextView) findViewById(R.id.androidWins);
        tt = (TextView) findViewById(R.id.numberTies);
        mResultsTextView = (TextView) findViewById(R.id.results);
        TextView identity = (TextView) findViewById(R.id.identity);
        identity.setText("Letra: " + Character.toString(player));
        mGame = new TicTacToeGame(mPrefs.getInt("mHumanWins", 0), mPrefs.getInt("mComputerWins", 0), mPrefs.getInt("mTies", 0));
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setGame(mGame);
        //mBoardView.setBoardColor(mPrefs.getInt("board_color", 0));
        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);
        addDataBaseListener();
        // addDataBaseListener();
        //mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.valueOf(mPrefs.getString("difficulty", TicTacToeGame.DifficultyLevel.Expert.name())));
        String difficultyLevel = mPrefs.getString("difficulty_level",
                getResources().getString(R.string.difficulty_harder));
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        else
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);

        turn = -1;
        humanWins = 0;
        androidWins = 0;
        ties = 0;
        if (savedInstanceState == null) {
            startNewGame();
            mGameOver = false;
            //humanWins = mPrefs.getInt("humanWins", 0);
            //androidWins = mPrefs.getInt("androidWins", 0);
            //ties = mPrefs.getInt("ties", 0);

        }
        else {
            // Restore the game's state
            mGame.setBoardState(savedInstanceState.getCharArray("board"));
            mGameOver = savedInstanceState.getBoolean("mGameOver");
            mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
            //humanWins = savedInstanceState.getInt("humanWins");
            //androidWins = savedInstanceState.getInt("androidWins");
            //ties = savedInstanceState.getInt("ties");
            selected = savedInstanceState.getInt("selected");
            //mTurn = savedInstanceState.getChar("mTurn");

        }
        displayScores();
    }

    private void addDataBaseListener(){
        DatabaseReference scores = mDatabase.child("games").child(gameName).child("scores");
        DatabaseReference player_turn = mDatabase.child("games").child(gameName).child("player_turn");
        DatabaseReference board = mDatabase.child("games").child(gameName).child("board");
        DatabaseReference init = mDatabase.child("games").child(gameName).child("init_turn");
        DatabaseReference gameOver = mDatabase.child("games").child(gameName).child("game_over");


        player_turn.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mTurn = dataSnapshot.getValue(String.class).charAt(0);
                checkWinner();
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("NOTIFI", "Failed to read value.", error.toException());
            }
        });

        board.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<List<String>> gti = new GenericTypeIndicator<List<String>>() {};
                List<String> newBoardList = dataSnapshot.getValue(gti);
                char newBoard[] = new char[newBoardList.size()];
                for(int i = 0; i < newBoardList.size(); i++){
                    newBoard[i] = newBoardList.get(i).charAt(0);
                }
                mGame.setBoardState(newBoard);
                mBoardView.invalidate();
                checkWinner();

            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("NOTIFI", "Failed to read value.", error.toException());
            }
        });

        scores.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                humanWins = dataSnapshot.child("x_wins").getValue(Integer.class);
                androidWins = dataSnapshot.child("o_wins").getValue(Integer.class);
                ties = dataSnapshot.child("ties").getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("NOTIFI", "Failed to read value.", databaseError.toException());

            }
        });

        init.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                turn = dataSnapshot.getValue(Integer.class);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("NOTIFI", "Failed to read value.", error.toException());
            }
        });

        gameOver.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mGameOver = dataSnapshot.getValue(Boolean.class);

            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("NOTIFI", "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == RESULT_CANCELED){
            //Apply potentially new settings
            mSoundOn = mPrefs.getBoolean("sound", true);

            String difficultyLevel = mPrefs.getString("difficulty_level",
                    getResources().getString(R.string.difficulty_harder));

            if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
            else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
            else
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putCharArray("board", mGame.getBoardState());
        outState.putBoolean("mGameOver", mGameOver);
        outState.putInt("humanWins", humanWins);
        outState.putInt("androidWins", androidWins);
        outState.putInt("ties", ties);
        outState.putCharSequence("info", mInfoTextView.getText());
        outState.putInt("turn", turn);
        outState.putInt("selected", selected);
        outState.putChar("mTurn", mTurn);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                showDialog(DIALOG_NEW_GAME_ID);
                //startNewGame();
                return true;
            case R.id.settings:
                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case R.id.resetScores:
                //humanWins = 0;
                //ties = 0;
                //androidWins = 0;
                //updateDisplay();
                Toast.makeText(this, "No disponible en modo online",
                        Toast.LENGTH_LONG).show();
                return true;
            case R.id.about:
                showDialog(10);

                return true;
        }
        return false;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.child("games").child(gameName).child("players").setValue(999);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id){
            case DIALOG_NEW_GAME_ID:
                if (!validateStartNewGame()){
                    break;
                }
                builder.setTitle(R.string.game_mode);

                final CharSequence[] levels = {
                        getResources().getString(R.string.one_player),
                        getResources().getString(R.string.multiplayer)
                };

                int selected = multiplayer ? 1 : 0;
                builder.setSingleChoiceItems(levels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int itemSelected) {
                        dialog.dismiss();
                        validateStartNewGame();
                        multiplayer = itemSelected == 1;

                        Toast.makeText(getApplicationContext(), multiplayer ? R.string.multiplayer : R.string.one_player, Toast.LENGTH_SHORT).show();
                        if(multiplayer) {
                            startNewGame();
                        } else {
                            Intent myIntent = new Intent(TicTacToeActivity.this, AndroidTicTacToeActivity.class);
                            TicTacToeActivity.this.startActivity(myIntent);
                        }
                    }
                });
                dialog = builder.create();
                break;
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog

                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                TicTacToeActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;

            case 10:

                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog, null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();
        }
        return dialog;
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Save the current scores
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("humanWins", humanWins);
        ed.putInt("androidWins", androidWins);
        ed.putInt("ties", ties);
        ed.putString("difficulty", mGame.getDifficultyLevel().name());
        ed.commit();
        super.onStop();
    }

    private void displayScores() {
        thw.setText("" + humanWins);
        taw.setText("" + androidWins);
        tt.setText("" + ties);
        mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
        mResultsTextView.setText("");
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.cero);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.equis);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }

    private void updateDisplay(){
        thw.setText("" + humanWins);
        taw.setText("" + androidWins);
        tt.setText("" + ties);
        mResultsTextView.setText("X wins: "+humanWins+" - Empates: "+ ties + " - O wins: " + androidWins);
        mResultsTextView.setText("");
    }

    boolean posEnabled(int pos){
        return mGame.posEnabled(pos);
    }
}