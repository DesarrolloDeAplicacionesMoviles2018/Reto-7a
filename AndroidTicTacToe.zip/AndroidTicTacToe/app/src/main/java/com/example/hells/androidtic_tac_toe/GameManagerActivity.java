package com.example.hells.androidtic_tac_toe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.firebase.database.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class GameManagerActivity extends AppCompatActivity {
    private Button mNewGameButton;
    private DatabaseReference mDatabase;
    private LinearLayout gameList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_manager);
        initializeElements();
    }

    private void initializeElements(){
        mNewGameButton = findViewById(R.id.new_online_game);
        gameList = (LinearLayout) findViewById(R.id.ll_btns);
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mNewGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Date date = new Date();
                DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
                Random rand = new Random();
                String gameName= "Game " + dateFormat.format(date) + " " + (rand.nextInt(1000) + 1);
                List<String> board = Arrays.asList(new String[]{" "," "," "," "," "," "," "," "," "});
                mDatabase = FirebaseDatabase.getInstance().getReference();
                mDatabase.child("games").child(gameName).child("players").setValue(1);
                mDatabase.child("games").child(gameName).child("player_turn").setValue("N");
                mDatabase.child("games").child(gameName).child("board").setValue(board);
                mDatabase.child("games").child(gameName).child("init_turn").setValue(-1);
                mDatabase.child("games").child(gameName).child("game_over").setValue(false);
                mDatabase.child("games").child(gameName).child("scores").child("x_wins").setValue(0);
                mDatabase.child("games").child(gameName).child("scores").child("o_wins").setValue(0);
                mDatabase.child("games").child(gameName).child("scores").child("ties").setValue(0);


                Intent myIntent = new Intent(GameManagerActivity.this, TicTacToeActivity.class);
                myIntent.putExtra("player", 'X');
                myIntent.putExtra("gameName", gameName);
                GameManagerActivity.this.startActivity(myIntent);
            }
        });
        showGameList();
    }

    private void showGameList(){
        DatabaseReference games = mDatabase.child("games");


        games.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                gameList.removeAllViews();
                for(DataSnapshot gameSnapshot: dataSnapshot.getChildren()){
                    int players = gameSnapshot.child("players").getValue(Integer.class);
                    final String gameName = gameSnapshot.getKey();
                    if(players < 2){
                        Button btn = new Button(GameManagerActivity.this);
                        btn.setText(gameName);
                        btn.setHighlightColor(Color.BLUE);
                        btn.setHintTextColor(Color.BLUE);
                        btn.setLinkTextColor(Color.BLUE);
                        gameList.addView(btn);
                        btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                mDatabase = FirebaseDatabase.getInstance().getReference();
                                mDatabase.child("games").child(gameName).child("players").setValue(2);
                                mDatabase.child("games").child(gameName).child("player_turn").setValue("X");
                                Intent myIntent = new Intent(GameManagerActivity.this, TicTacToeActivity.class);
                                myIntent.putExtra("player", 'O');
                                myIntent.putExtra("gameName", gameName);
                                GameManagerActivity.this.startActivity(myIntent);
                            }
                        });

                    }
                    Log.d("asdfg", gameName);

                }
            }

            @Override
            public void onCancelled(DatabaseError error){
                //Failed to read value
                Log.w("NOTIFY", "Failed to read value.", error.toException());
            }
        });
    }
}